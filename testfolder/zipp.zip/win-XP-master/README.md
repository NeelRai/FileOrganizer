## Hello World!
Felt nostalgic while creating this my first desktop computer use to have Win XP.

Demo Link: https://battleplayer02.github.io/win-XP/WinXP/

This is my submission for PepHack-2. I have created a Windows XP Experience on the web. Try it on your system with the link mentioned below.
Features:
- Desktop icons are clickable. Double-clicking them will open the application
- Right-click on the desktop to see menu.
- Time in system-tray is your system's time.
- Rename Delete Open by right-clicking on the desktop apps.
- All the windows are draggable, closable, minimizable, and maximizable. Try it.
- It also has Excel Clone, Word Clone, and some other apps.
- Click on the VS Code Icon in there to have a look at the code I have tried to add comments for better understanding.


Do follow me on Github (@battleplayer02) and Linkedin (@hshekhar02).

Special thanks to Jasbir Sir and Sumeet Malik Sir for organizing the hackathon.


Demo: https://lnkd.in/dvVGxGp
Github: https://lnkd.in/dhrh_CB
Link: https://lnkd.in/div78kU

![image](https://user-images.githubusercontent.com/42701850/120933660-b5e8af80-c718-11eb-8d1a-193a67b6c62a.png)
![image](https://user-images.githubusercontent.com/42701850/120933669-be40ea80-c718-11eb-94d0-32b4d5ef02d9.png)
![image](https://user-images.githubusercontent.com/42701850/120933670-c00aae00-c718-11eb-8673-c6ce847f0ede.png)
![image](https://user-images.githubusercontent.com/42701850/120933674-c567f880-c718-11eb-8ca1-0dd0db6b3c5c.png)
